/* Техцентр — минимальный JavaScript: только модальное окно записи */
(function () {
  'use strict';

  var WHATSAPP_PHONE = '79258900270';

  var modal = document.getElementById('booking-modal');
  var form = document.getElementById('booking-form');
  if (!modal || !form) return;

  var nameInput = document.getElementById('bf-name');
  var phoneInput = document.getElementById('bf-phone');
  var serviceSelect = document.getElementById('bf-service');
  var lastFocused = null;

  function openModal() {
    lastFocused = document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    window.setTimeout(function () {
      if (nameInput) nameInput.focus();
    }, 150);
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus();
    }
  }

  // Кнопки открытия («Записаться онлайн», «Записаться» в шапке и т.д.)
  Array.prototype.forEach.call(
    document.querySelectorAll('[data-open-modal]'),
    function (btn) {
      btn.addEventListener('click', openModal);
    }
  );

  // Закрытие: крестик и клик по затемнению
  Array.prototype.forEach.call(
    modal.querySelectorAll('[data-close-modal]'),
    function (el) {
      el.addEventListener('click', closeModal);
    }
  );

  // Закрытие по Escape
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) {
      closeModal();
    }
  });

  // Отправка формы: собираем данные и открываем WhatsApp
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
      form.reportValidity();
      return;
    }

    var name = nameInput ? nameInput.value.trim() : '';
    var phone = phoneInput ? phoneInput.value.trim() : '';
    var service = serviceSelect ? serviceSelect.value : '';

    var text =
      'Здравствуйте! Хочу записаться в техцентр.\n' +
      'Имя: ' + name + '\n' +
      'Телефон: ' + phone + '\n' +
      'Услуга: ' + service;

    var url = 'https://wa.me/' + WHATSAPP_PHONE + '?text=' + encodeURIComponent(text);

    // Открываем WhatsApp в новой вкладке (без 'noopener': этот флаг делает
    // возвращаемое значение window.open равным null и ломал бы логику fallback)
    var win = window.open(url, '_blank');
    if (win) {
      win.opener = null; // защита от обратного доступа к нашей странице
      win.focus();
    } else {
      window.location.href = url; // запасной вариант, если браузер заблокировал popup
    }

    form.reset();
    closeModal();
  });
})();
